import gradio as gr

from agents.memory_agent import MemoryAgent
from agents.research_agent import ResearchAgent
from agents.analysis_agent import AnalysisAgent
from agents.coordinator import Coordinator

memory = MemoryAgent()
research = ResearchAgent()
analysis = AnalysisAgent()
manager = Coordinator(memory=memory, research=research, analysis=analysis)

MODE_MAP = {
    "Auto": "auto",
    "Web only (mock KB)": "web_only",
    "Memory only": "memory_only",
    "Web + Analysis": "web_plus_analysis",
}

def run_query(query: str, mode: str, show_trace: bool):
    forced = MODE_MAP.get(mode, "auto")
    out = manager.answer(query, forced_mode=forced)

    trace_text = ""
    if show_trace:
        trace_text = "\n".join([str(t) for t in out["trace"]])

    return out["final"], trace_text

with gr.Blocks() as demo:
    gr.Markdown("# Multi-Agent Chat (A03) — Lab Style")

    mode = gr.Radio(
        ["Auto", "Web only (mock KB)", "Memory only", "Web + Analysis"],
        value="Auto",
        label="Mode",
    )
    show_trace = gr.Checkbox(value=True, label="Show trace")

    query = gr.Textbox(label="Your query", placeholder="Type your question...")
    btn = gr.Button("Run")

    answer = gr.Textbox(label="Answer", lines=8)
    trace = gr.Textbox(label="Trace", lines=12)

    btn.click(run_query, inputs=[query, mode, show_trace], outputs=[answer, trace])

demo.launch()


