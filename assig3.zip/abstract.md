# One-Pager Abstract — Multi-Agent Chat System (KRR A03)

## Goal
Build a small multi-agent chat system where a manager agent routes tasks to worker agents, and the system maintains memory (conversation + knowledge) with retrieval.

## Agents
- **Coordinator:** manager that plans the steps and merges results
- **ResearchAgent:** retrieves from a preloaded mock knowledge base (mock web search)
- **AnalysisAgent:** simple reasoning (compare/summarize)
- **MemoryAgent:** stores long-term memory and supports keyword + vector similarity retrieval

## How a typical query works
Example query: “Research transformer architectures, analyze efficiency trade-offs”
1) Coordinator calls ResearchAgent → gets relevant docs from mock KB  
2) Coordinator calls AnalysisAgent → generates a short analysis/summary  
3) Coordinator stores final answer into MemoryAgent (so it can be reused later)

If user later asks “what did we discuss earlier about transformers?”, Coordinator uses MemoryAgent to retrieve the stored information.

## Memory design
Stored items:
- Conversation turns (timestamp + role + metadata)
- Knowledge base records (final answers with provenance)
- Agent state per task (what each agent did)
Retrieval:
- keyword/topic match
- TF-IDF vector similarity search (simple vector store)

## System diagram
```mermaid
flowchart LR
U[User] --> C[Coordinator / Manager]
C --> R[ResearchAgent (mock web KB)]
R --> C
C --> A[AnalysisAgent]
A --> C
C --> M[MemoryAgent]
M --> C
C --> U
