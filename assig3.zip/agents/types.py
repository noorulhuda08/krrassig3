from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict

#just a common format for messages and replies between agents.
#So Coordinator sends an AgentMessage to agents, and agents return an AgentResult back (same structure every time → fewer bugs).
@dataclass
class AgentMessage:
    # Coordinator -> Agent (what to do + data)
    sender: str
    receiver: str
    type: str
    payload: Dict[str, Any]


@dataclass
class AgentResult:
    # Agent -> Coordinator (success/fail + answer + extra info)
    ok: bool
    text: str = ""
    confidence: float = 0.5
    meta: Dict[str, Any] = field(default_factory=dict)
