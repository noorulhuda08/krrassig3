from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from .analysis_agent import AnalysisAgent
from .memory_agent import MemoryAgent
from .research_agent import ResearchAgent
from .types import AgentMessage


class Coordinator:
    """
    Coordinator / Manager:
    - plans steps
    - calls agents (message passing)
    - stores final answer to memory
    - keeps trace for debugging
    """

    def __init__(self, *, memory: MemoryAgent, research: ResearchAgent, analysis: AnalysisAgent) -> None:
        self.memory = memory
        self.research = research
        self.analysis = analysis
        self.trace: List[Dict[str, Any]] = []

    def answer(self, user_query: str, forced_mode: str = "auto") -> Dict[str, Any]:
        task_id = str(uuid.uuid4())[:8]
        self.trace = []

        self._trace("USER", "Coordinator", {"query": user_query, "task_id": task_id})
        self.memory.add_conversation_turn("user", user_query, meta={"task_id": task_id})

        # Reuse from memory if similar
        if forced_mode == "auto":
            prior = self.memory.find_similar_fact(user_query)
            if prior:
                rec, score = prior
                self._trace("Coordinator", "MemoryAgent", {"action": "reuse", "score": round(score, 3), "record_id": rec.id})
                final = f"(From memory)\n{rec.text}"
                self.memory.add_conversation_turn("assistant", final, meta={"task_id": task_id})
                return {"task_id": task_id, "mode": "MEMORY_REUSE", "final": final, "trace": self.trace}

        plan = self._plan(user_query, forced_mode)
        self._trace("Coordinator", "Planner", {"plan": plan})

        research_docs: List[Dict[str, Any]] = []
        analysis_text: Optional[str] = None

        for step in plan:
            if step == "RESEARCH":
                msg = AgentMessage(
                    sender="Coordinator",
                    receiver="ResearchAgent",
                    type="search",
                    payload={"query": user_query, "top_k": 3},
                )
                self._trace(msg.sender, msg.receiver, msg.payload)
                res = self.research.handle(msg)

                self.memory.upsert_agent_state("ResearchAgent", task_id, "done" if res.ok else "failed", "mock kb search")
                research_docs = list(res.meta.get("results", [])) if res.ok else []

            elif step == "ANALYZE":
                msg = AgentMessage(
                    sender="Coordinator",
                    receiver="AnalysisAgent",
                    type="analyze",
                    payload={"query": user_query, "research_results": research_docs},
                )
                self._trace(msg.sender, msg.receiver, {"payload_keys": list(msg.payload.keys())})
                res = self.analysis.handle(msg)

                self.memory.upsert_agent_state("AnalysisAgent", task_id, "done" if res.ok else "failed", "analysis")
                analysis_text = res.text if res.ok else "Analysis failed."

            elif step == "MEMORY_LOOKUP":
                hits = self.memory.vector_search(user_query, top_k=3)
                if hits:
                    lines = ["Memory matches:"]
                    for rec, s in hits:
                        lines.append(f"- [{rec.topic}] {rec.text} (score={s:.2f})")
                    analysis_text = "\n".join(lines)
                else:
                    analysis_text = "No relevant info found in memory."

                self.memory.upsert_agent_state("MemoryAgent", task_id, "done", "vector search")

        final = self._synthesize(user_query, research_docs, analysis_text)
        self.memory.add_conversation_turn("assistant", final, meta={"task_id": task_id, "plan": plan})

        # store final as a knowledge record (so later memory lookup works)
        self.memory.add_knowledge(
            record_id=f"fact_{task_id}",
            text=final,
            topic=self._topic_hint(user_query),
            source="system:coordinator",
            agent="Coordinator",
            confidence=0.7,
            extra={"plan": plan},
        )

        return {"task_id": task_id, "mode": "+".join(plan), "final": final, "trace": self.trace}

    def _plan(self, q: str, forced_mode: str) -> List[str]:
        ql = q.lower()

        if forced_mode == "web_only":
            return ["RESEARCH"]

        if forced_mode == "memory_only":
            return ["MEMORY_LOOKUP"]

        if forced_mode == "web_plus_analysis":
            return ["RESEARCH", "ANALYZE"]

        # auto:
        if any(k in ql for k in ["what did we", "earlier", "previously", "from memory"]):
            return ["MEMORY_LOOKUP"]

        if any(k in ql for k in ["analyze", "compare", "recommend", "tradeoff", "trade-off", "efficiency"]):
            return ["RESEARCH", "ANALYZE"]

        return ["RESEARCH"]

    def _synthesize(self, user_query: str, docs: List[Dict[str, Any]], analysis_text: Optional[str]) -> str:
        if analysis_text:
            return analysis_text.strip()

        if docs:
            lines = ["Answer (from mock web KB):"]
            for d in docs[:2]:
                lines.append(f"- {d.get('title','')}: {d.get('content','')}")
            return "\n".join(lines)

        return "I couldn't find enough information in the mock knowledge base."

    @staticmethod
    def _topic_hint(q: str) -> str:
        ql = q.lower()
        if "australia" in ql:
            return "australia"
        if "sydney" in ql:
            return "sydney"
        if "opera" in ql:
            return "landmark"
        return "general"

    def _trace(self, sender: str, receiver: str, payload: Dict[str, Any]) -> None:
        self.trace.append({"from": sender, "to": receiver, "payload": payload})
