from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .types import AgentMessage, AgentResult


def _tokens(text: str) -> List[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


class ResearchAgent:
    """
    Research Agent (A03):
    Simulate information retrieval using a pre-loaded knowledge base (mock web search).
    """

    def __init__(self, kb_path: str = "data/mock_web_kb.json") -> None:
        self.kb_path = Path(kb_path)
        self.docs: List[Dict[str, Any]] = []
        self._load_kb()

    def _load_kb(self) -> None:
        if not self.kb_path.exists():
            self.docs = []
            return
        self.docs = json.loads(self.kb_path.read_text(encoding="utf-8"))

    def handle(self, msg: AgentMessage) -> AgentResult:
        if msg.type != "search":
            return AgentResult(ok=False, text="ResearchAgent: unsupported message type.", meta={})

        query = str(msg.payload.get("query", "")).strip()
        top_k = int(msg.payload.get("top_k", 3))

        results = self.search_mock(query, top_k=top_k)
        return AgentResult(ok=True, text="", confidence=0.6, meta={"results": results})

    def search_mock(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        q_tokens = set(_tokens(query))
        if not q_tokens:
            return []

        scored: List[Tuple[float, Dict[str, Any]]] = []

        for d in self.docs:
            blob = f"{d.get('title','')} {d.get('content','')} {' '.join(d.get('topics', []))}"
            d_tokens = set(_tokens(blob))

            overlap = len(q_tokens & d_tokens)
            score = overlap / max(1, len(q_tokens))  # simple overlap score

            if score > 0:
                scored.append(
                    (
                        score,
                        {
                            "id": d.get("id", ""),
                            "title": d.get("title", ""),
                            "content": d.get("content", ""),
                            "url": d.get("url", ""),
                            "topics": d.get("topics", []),
                            "score": round(score, 4),
                            "source": "mock_kb",
                        },
                    )
                )

        scored.sort(key=lambda x: x[0], reverse=True)
        return [x[1] for x in scored[:top_k]]
