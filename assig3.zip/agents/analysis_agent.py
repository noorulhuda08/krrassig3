from __future__ import annotations

from typing import Any, Dict, List

from .types import AgentMessage, AgentResult


class AnalysisAgent:
    """
    Analysis Agent:
    takes retrieved docs + user query and produces a short summary / comparison.
    """

    def handle(self, msg: AgentMessage) -> AgentResult:
        if msg.type != "analyze":
            return AgentResult(ok=False, text="AnalysisAgent: unsupported message type.", confidence=0.0)

        query = str(msg.payload.get("query", "")).strip()
        docs: List[Dict[str, Any]] = list(msg.payload.get("research_results", []))

        if not docs:
            return AgentResult(ok=True, text="No data found to analyze.", confidence=0.3)

        ql = query.lower()
        want_compare = any(k in ql for k in ["compare", "difference", "tradeoff", "trade-off", "which is better", "recommend"])

        if want_compare and len(docs) >= 2:
            a, b = docs[0], docs[1]
            text = (
                "Comparison (from retrieved docs):\n"
                f"- A: {a.get('title','')}: {a.get('content','')}\n"
                f"- B: {b.get('title','')}: {b.get('content','')}\n"
                "\nSimple recommendation:\n"
                "- Choose the one that matches your goal (speed/simplicity vs accuracy/power)."
            )
            return AgentResult(ok=True, text=text, confidence=0.75)

        # default: short summary
        lines = ["Summary (from retrieved docs):"]
        for d in docs[:3]:
            lines.append(f"- {d.get('title','')}: {d.get('content','')}")
        return AgentResult(ok=True, text="\n".join(lines), confidence=0.7)
