from __future__ import annotations

import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer


@dataclass
class KnowledgeRecord:
    id: str
    text: str
    topic: str
    source: str
    agent: str
    confidence: float
    ts: float
    extra: Dict[str, Any]


class MemoryAgent:
    """
    MemoryAgent:
    - conversation memory (jsonl)
    - knowledge memory (json)
    - agent state memory (json)
    - search: keyword/topic + vector similarity (TF-IDF cosine)
    """

    def __init__(self, storage_dir: str = "storage") -> None:
        self.storage = Path(storage_dir)
        self.storage.mkdir(parents=True, exist_ok=True)

        self.conv_path = self.storage / "conversation.jsonl"
        self.kb_path = self.storage / "knowledge.json"
        self.state_path = self.storage / "agent_state.json"

        self.knowledge: List[KnowledgeRecord] = self._load_kb()
        self.agent_state: Dict[str, Any] = self._load_state()

        self._vectorizer: Optional[TfidfVectorizer] = None
        self._kb_matrix = None
        self._rebuild_index()

    # ---------- conversation ----------
    def add_conversation_turn(self, role: str, text: str, meta: Optional[Dict[str, Any]] = None) -> None:
        row = {"ts": time.time(), "role": role, "text": text, "meta": meta or {}}
        with self.conv_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    # ---------- knowledge ----------
    def add_knowledge(
        self,
        record_id: str,
        text: str,
        topic: str,
        source: str,
        agent: str,
        confidence: float,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        rec = KnowledgeRecord(
            id=record_id,
            text=text,
            topic=topic,
            source=source,
            agent=agent,
            confidence=float(confidence),
            ts=time.time(),
            extra=extra or {},
        )
        self.knowledge.append(rec)
        self._save_kb()
        self._rebuild_index()

    def keyword_search(self, query: str, top_k: int = 3) -> List[KnowledgeRecord]:
        q = query.lower().strip()
        hits = [r for r in self.knowledge if q in r.text.lower() or q in r.topic.lower()]
        return hits[:top_k]

    def vector_search(self, query: str, top_k: int = 3) -> List[Tuple[KnowledgeRecord, float]]:
        if not self.knowledge or self._vectorizer is None or self._kb_matrix is None:
            return []

        q_vec = self._vectorizer.transform([query])
        scores = (self._kb_matrix @ q_vec.T).toarray().ravel()  # cosine in TF-IDF
        idxs = np.argsort(-scores)[:top_k]

        out: List[Tuple[KnowledgeRecord, float]] = []
        for i in idxs:
            out.append((self.knowledge[int(i)], float(scores[int(i)])))
        return out

    def find_similar_fact(self, query: str, threshold: float = 0.35) -> Optional[Tuple[KnowledgeRecord, float]]:
        hits = self.vector_search(query, top_k=1)
        if not hits:
            return None
        rec, score = hits[0]
        if score >= threshold:
            return rec, score
        return None

    # ---------- agent state ----------
    def upsert_agent_state(self, agent: str, task_id: str, status: str, notes: str = "") -> None:
        self.agent_state.setdefault(task_id, {})
        self.agent_state[task_id][agent] = {"status": status, "notes": notes, "ts": time.time()}
        self._save_state()

    # ---------- persistence ----------
    def _load_kb(self) -> List[KnowledgeRecord]:
        if not self.kb_path.exists():
            return []
        raw = json.loads(self.kb_path.read_text(encoding="utf-8"))
        return [KnowledgeRecord(**x) for x in raw]

    def _save_kb(self) -> None:
        raw = [asdict(x) for x in self.knowledge]
        self.kb_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")

    def _load_state(self) -> Dict[str, Any]:
        if not self.state_path.exists():
            return {}
        return json.loads(self.state_path.read_text(encoding="utf-8"))

    def _save_state(self) -> None:
        self.state_path.write_text(json.dumps(self.agent_state, ensure_ascii=False, indent=2), encoding="utf-8")

    def _rebuild_index(self) -> None:
        if not self.knowledge:
            self._vectorizer = None
            self._kb_matrix = None
            return
        texts = [r.text for r in self.knowledge]
        self._vectorizer = TfidfVectorizer(stop_words="english")
        self._kb_matrix = self._vectorizer.fit_transform(texts)
