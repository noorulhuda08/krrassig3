import os

from agents.memory_agent import MemoryAgent
from agents.research_agent import ResearchAgent
from agents.analysis_agent import AnalysisAgent
from agents.coordinator import Coordinator

# 5 scenarios -> saves outputs/*.txt
SCENARIOS = [
    ("simple_query.txt", "web_only", "What is the capital of Australia?"),
    ("complex_query.txt", "web_plus_analysis", "Compare Sydney and Melbourne and recommend which is better for tourism."),
    ("memory_test.txt", "memory_only", "What did we discuss earlier about the capital of Australia?"),
    ("multi_step.txt", "web_plus_analysis", "Find info about Australian states and territories, analyze it, and identify how many there are."),
    ("collaborative.txt", "web_plus_analysis", "Compare Uluru and the Great Barrier Reef and recommend which is better for nature tourism."),
]

def main():
    os.makedirs("outputs", exist_ok=True)

    memory = MemoryAgent()
    research = ResearchAgent()
    analysis = AnalysisAgent()
    manager = Coordinator(memory=memory, research=research, analysis=analysis)

    for filename, mode, query in SCENARIOS:
        out = manager.answer(query, forced_mode=mode)

        lines = []
        lines.append(f"MODE: {mode}")
        lines.append(f"QUERY: {query}\n")
        lines.append("ANSWER:\n" + out["final"] + "\n")
        lines.append("TRACE:")
        for t in out["trace"]:
            lines.append(str(t))

        with open(os.path.join("outputs", filename), "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    print("Done ✅ Check outputs/ for 5 files.")

if __name__ == "__main__":
    main()
