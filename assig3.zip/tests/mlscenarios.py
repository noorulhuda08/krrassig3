
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(__file__)))


from agents.memory_agent import MemoryAgent
from agents.research_agent import ResearchAgent
from agents.analysis_agent import AnalysisAgent
from agents.coordinator import Coordinator

SCENARIOS = [
    ("simple_queryml.txt", "web_only", "What are the main types of neural networks?"),
    ("complex_queryml.txt", "web_plus_analysis", "Research transformer architectures, analyze their computational efficiency, and summarize key trade-offs."),
    ("memory_testml.txt", "memory_only", "What did we discuss about neural networks earlier?"),
    ("multi_stepml.txt", "web_plus_analysis", "Find recent papers on reinforcement learning, analyze their methodologies, and identify common challenges."),
    ("collaborativeml.txt", "web_plus_analysis", "Compare two machine-learning approaches and recommend which is better for our use case.")
]
def main():
    os.makedirs("outputs", exist_ok=True)

    memory = MemoryAgent()
    research = ResearchAgent()
    analysis = AnalysisAgent()
    manager = Coordinator(memory=memory, research=research, analysis=analysis)

    for filename, mode, query in SCENARIOS:
        out = manager.answer(query, forced_mode=mode)

        lines = []
        lines.append(f"MODE: {mode}")
        lines.append(f"QUERY: {query}\n")
        lines.append("ANSWER:\n" + out["final"] + "\n")
        lines.append("TRACE:")
        for t in out["trace"]:
            lines.append(str(t))

        with open(os.path.join("outputs", filename), "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    print("Done ✅ Check outputs/ for 5 files.")

if __name__ == "__main__":
    main()
